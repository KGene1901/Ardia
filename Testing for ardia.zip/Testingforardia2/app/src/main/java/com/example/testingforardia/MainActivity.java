package com.example.testingforardia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import static android.widget.ImageView.ScaleType.FIT_XY;
import static com.example.testingforardia.R.id.button;
import static com.example.testingforardia.R.id.feed;
import static com.example.testingforardia.R.id.linearLayout1;


import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerview;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    Button btn;
    TextView likes;
    CardView post;
    ImageView imageV1;
    LinearLayout llyaout_v;
    LinearLayout llyaout_h;
    LinearLayout LL;
    TextView comments;
    private static final int PICK_IMAGE = 100;
    private BroadcastReceiver minuteUpdate;
    private RecyclerView postfeed;
    Uri imageUri;
    int counter = 0;

    // Working on lines 55 to 76 for recycler view - Website used: https://developer.android.com/guide/topics/ui/layout/recyclerview
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = (Button) findViewById(button);
        recyclerview = (RecyclerView) findViewById(R.id.my_rv);

        layoutManager = new LinearLayoutManager(this);
        recyclerview.setLayoutManager(layoutManager);

        mAdapter = new MyAdapter(myDataset);
        recyclerview.setAdapter(mAdapter);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

    }

// I just copied and pasted lines 78 to 124 - have not tried to adapt them yet to my code
    public static class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
        private String[] mDataset;

        // Provide a reference to the views for each data item
        // Complex data items may need more than one view per item, and
        // you provide access to all the views for a data item in a view holder
        public static class MyViewHolder extends RecyclerView.ViewHolder {
            // each data item is just a string in this case
            public TextView textView;
            public MyViewHolder(TextView v) {
                super(v);
                textView = v;
            }
        }

        // Provide a suitable constructor (depends on the kind of dataset)
        public MyAdapter(String[] myDataset) {
            mDataset = myDataset;
        }

        // Create new views (invoked by the layout manager)
        @Override
        public MyAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                         int viewType) {
            // create a new view
            TextView v = (TextView) LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.my_text_view, parent, false);
        ...
            MyViewHolder vh = new MyViewHolder(v);
            return vh;
        }

        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(MyViewHolder holder, int position) {
            // - get element from your dataset at this position
            // - replace the contents of the view with that element
            holder.textView.setText(mDataset[position]);

        }

        // Return the size of your dataset (invoked by the layout manager)
        @Override
        public int getItemCount() {
            return mDataset.length;
        }
    }


    private void openGallery(){
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(gallery, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && requestCode == PICK_IMAGE){
            imageUri = data.getData();
            postCreate();
        }
    }

    public int randomNum(int n){
        Random rand = new Random();
        int UB = n;
        return rand.nextInt(UB);
    }

    protected void commentGenerator() {
        List<String> textOption = new ArrayList<>(Arrays.asList("Very nice", "That's an awesome picture", "Looking good man!", "That's pretty cool:)", "Love this pictures<3"));
        List<String> userOption = new ArrayList<>(Arrays.asList("Ben109", "Desmond_xy", "Maddie_Chia", "Karl", "Jess"));
        comments = new TextView(this);
        comments.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        comments.setText(userOption.get(randomNum(userOption.size())) + " said: " + textOption.get(randomNum(textOption.size())));
        comments.setBackgroundColor(0xffffffff); // hex color 0xAARRGGBB
        comments.setPadding(20, 20, 20, 0);// in pixels (left, top, right, bottom)
        llyaout_h.addView(comments);
    }

    protected void cardGenerator() {
        post = new CardView(this);
        post.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        post.setRadius(5);
    }

    protected void linearLayout_v() {
        llyaout_v = new LinearLayout(this);
        llyaout_v.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        llyaout_v.setOrientation(LinearLayout.VERTICAL);
    }

    protected void linearLayout_h() {
        llyaout_h = new LinearLayout(this);
        llyaout_h.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        llyaout_h.setOrientation(LinearLayout.HORIZONTAL);
    }

    protected void imgCreate () {
        imageV1 = new ImageView(this);
        imageV1.setImageURI(imageUri);
        imageV1.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        imageV1.setScaleType(FIT_XY);
        imageV1.setPadding(0,20,0,20);
    }

    protected void likeCount() {
        likes = new TextView(this);
        likes.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        likes.setText("Awaiting likes from your friends");
        likes.setBackgroundColor(0xffffffff);
        likes.setPadding(20, 20, 20, 0);
    }


    public void postCreate() {
        LL = (LinearLayout) findViewById(linearLayout1);
        cardGenerator();
        linearLayout_v();
        imgCreate();
        linearLayout_h();
        post.addView(llyaout_v);
        llyaout_v.addView(imageV1);
        likeCount();
        llyaout_v.addView(likes);
        llyaout_v.addView(llyaout_h);
        LL.addView(post);
    }


    public void startUpdate() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_TIME_TICK);
        minuteUpdate = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                commentGenerator();
                counter++;
                likes.setText(counter + " people liked your photo");

            }
        };
        registerReceiver(minuteUpdate, intentFilter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        startUpdate();
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(minuteUpdate);
    }
    }