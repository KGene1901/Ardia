package com.example.testingforardia;
import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import static com.example.testingforardia.R.id.list_o_comments;


public class CommentActivity extends MainActivity {
    ArrayList<Comment> com = new ArrayList<>();
    private ListView mCommentList;
    private BroadcastReceiver minuteUpdate;
    int counter = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.comment_section);
        mCommentList = (ListView) findViewById(list_o_comments);

    }


    public void startUpdate() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_TIME_TICK);
        final CommentListAdapter adaptr = new CommentListAdapter(this, R.layout._comment_, com);
        minuteUpdate = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                MainActivity ma = new MainActivity();
                String newComment = ma.commentGenerator();
                counter++;
//                LinearLayout commentSect = (LinearLayout) findViewById(R.id.commentSect);
////                TextView COMMENT = (TextView) findViewById(textView3);
//                newC.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
//                newC.setTextSize(16);
//                newC.setText(newComment);
//                commentSect.addView(newC);
//                COMMENT.setText(newComment);
                com.add(new Comment(newComment));
                mCommentList.setAdapter(adaptr);
            }
        };
        registerReceiver(minuteUpdate, intentFilter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        startUpdate();
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(minuteUpdate);
    }
}
