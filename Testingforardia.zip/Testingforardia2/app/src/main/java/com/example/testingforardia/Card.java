package com.example.testingforardia;

public class Card {
    private String imgURI;
    private int likes;
    private String comments;

    public Card(String imgURI, int likes, String comments) {
        this.imgURI = imgURI;
        this.likes = likes;
        this.comments = comments;
    }

    public String getImgURI() {
        return imgURI;
    }

    public void setImgURI(String imgURI) {
        this.imgURI = imgURI;
    }

    public int getLikes() {
        return likes;
    }

    public void setLikes(int likes) {
        this.likes = likes;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
}
