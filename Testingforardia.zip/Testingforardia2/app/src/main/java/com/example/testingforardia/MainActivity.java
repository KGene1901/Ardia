package com.example.testingforardia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import static android.widget.ImageView.ScaleType.FIT_XY;
import static com.example.testingforardia.R.id.button;
import static com.example.testingforardia.R.id.list_o_cards;
import static com.example.testingforardia.R.id.list_o_comments;
import static com.example.testingforardia.R.id.textView2;
import static com.example.testingforardia.R.id.textView3;


import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextClock;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button btn;
    TextView likes;
    private static final int PICK_IMAGE = 100;
    private BroadcastReceiver minuteUpdate;
    private TextView newC;
    Uri imageUri;
    int counter = 1;
    private ListView mListView;

    ArrayList<Card> feed = new ArrayList<>();
    ArrayList<String> images = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.card_list);
        btn = (Button) findViewById(button);
        mListView = (ListView) findViewById(list_o_cards);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });
    }

    private void openGallery() {
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(gallery, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == PICK_IMAGE) {
            imageUri = data.getData();
            images.add(imageUri.toString());
            String comments = commentGenerator();
            int likeCounter = 1;
            feed.add(new Card(imageUri.toString(), likeCounter, comments));
            CustomListAdapter adapter = new CustomListAdapter(this, R.layout.activity_main, feed);
            mListView.setAdapter(adapter);
        }
    }

    public int randomNum(int n) {
        Random rand = new Random();
        int UB = n;
        return rand.nextInt(UB);
    }

    protected String commentGenerator() {
        List<String> textOption = new ArrayList<>(Arrays.asList("Very nice", "That's an awesome picture", "Looking good man!", "That's pretty cool:)", "Love this picture<3", "Damn, you're photogrpahy skills have improved", "Nice!", "Lovely picture.", "First", "Second"));
        List<String> userOption = new ArrayList<>(Arrays.asList("Ben109", "Desmond_xy", "Maddie_Chia", "Karl", "Jess", "MLH", "Tom Holland", "Dr Strange", "hearts_xo_May", "some_spam_account", "Wave190", "Josh420"));
        return (userOption.get(randomNum(userOption.size())) + " said: " + textOption.get(randomNum(textOption.size())));
    }

    public void startUpdate() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_TIME_TICK);
        newC = new TextView(this);
        minuteUpdate = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
//                String newComment = commentGenerator();
                counter++;
                TextView LIKE = (TextView) findViewById(textView2);
//                LinearLayout commentSect = (LinearLayout) findViewById(R.id.commentSect);
////                TextView COMMENT = (TextView) findViewById(textView3);
                LIKE.setText(Integer.toString(counter) + " people have liked your photo.");
//                newC.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
//                newC.setTextSize(16);
//                newC.setText(newComment);
//                commentSect.addView(newC);
//                COMMENT.setText(newComment);
            }
        };
        registerReceiver(minuteUpdate, intentFilter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        startUpdate();
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(minuteUpdate);
    }


    public void open_comments(View v){
        android.content.Intent commentIntent = new android.content.Intent(MainActivity.this, CommentActivity.class);
        commentIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(commentIntent);
    }
    }