package com.example.testingforardia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import static android.widget.ImageView.ScaleType.FIT_XY;
import static com.example.testingforardia.R.id.button;


import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ImageView imgView;
    Button btn;
    private static final int PICK_IMAGE = 100;
    private BroadcastReceiver minuteUpdate;
    Uri imageUri;
    LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linearLayout1);
    CardView cardV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = (Button) findViewById(button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

    }
    private void openGallery(){
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(gallery, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && requestCode == PICK_IMAGE){
            imageUri = data.getData();
            postCreate();
        }
    }

    public int randomNum(int n){
        Random rand = new Random();
        int UB = n;
        return rand.nextInt(UB);
    }

    protected void randomComment() {
        List<String> textOption = new ArrayList<>(Arrays.asList("Very nice", "That's an awesome picture", "Looking good man!", "That's pretty cool:)", "Love those pictures<3"));
        List<String> userOption = new ArrayList<>(Arrays.asList("Ben109", "Desmond_xy", "Maddie_Chia", "Karl", "Jess"));
        TextView textView1 = new TextView(this);
        textView1.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        textView1.setText(userOption.get(randomNum(userOption.size())) + " said: " + textOption.get(randomNum(textOption.size())));
        textView1.setBackgroundColor(0xffffffff); // hex color 0xAARRGGBB
        textView1.setPadding(20, 20, 20, 20);// in pixels (left, top, right, bottom)
        textView1.setTranslationY(150);
        cardV.addView(textView1);
    }


    protected void postCreate() {
        cardV = new CardView(this);
        cardV.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        ImageView imageV1 = new ImageView(this);
        imageV1.setImageURI(imageUri);
        imageV1.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        imageV1.setScaleType(FIT_XY);
        imageV1.setPadding(0,20,0,20);
        cardV.addView(imageV1);
        randomComment();
        linearLayout.addView(cardV);
    }

    public void startUpdate() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_TIME_TICK);
        minuteUpdate = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                randomComment();
            }
        };
        registerReceiver(minuteUpdate, intentFilter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        startUpdate();
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(minuteUpdate);
    }
    }